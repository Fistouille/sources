These examples are ports from the [Microsoft Azure IoT device SDK for C](https://github.com/Azure/azure-iot-sdks/blob/master/c/readme.md).

 * [iothub_client_sample_http](iothub_client_sample_http) is from: https://github.com/Azure/azure-iot-sdks/tree/master/c/iothub_client/samples/iothub_client_sample_http
 * [simplesample_http](simplesample_http) is from: https://github.com/Azure/azure-iot-sdks/tree/master/c/serializer/samples/simplesample_http
