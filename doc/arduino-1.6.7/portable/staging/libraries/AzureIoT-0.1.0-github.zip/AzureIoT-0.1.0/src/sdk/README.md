These source files are from the [Microsoft Azure IoT device SDK for C](https://github.com/Azure/azure-iot-sdks/blob/master/c/readme.md).

Specifically:

 * https://github.com/Azure/azure-iot-sdks/tree/master/c/common (```adapters```, ```inc``` and ```src```)
 * https://github.com/Azure/azure-iot-sdks/tree/master/c/iothub_client (```inc``` and ```src```)
 * https://github.com/Azure/azure-iot-sdks/tree/master/c/serializer (```inc``` and ```src```)
